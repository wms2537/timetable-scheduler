#!/usr/bin/env python3
"""
Simple HTTP Server for testing the School Scheduler web interface.
"""

import http.server
import socketserver
import os
import webbrowser
from urllib.parse import urlparse

# Configuration
PORT = 8000
DIRECTORY = os.path.dirname(os.path.abspath(__file__))

class Handler(http.server.SimpleHTTPRequestHandler):
    """Custom request handler with directory override."""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)
    
    def log_message(self, format, *args):
        """Override to add color and make logs more readable."""
        if args[0].startswith('GET'):
            path = urlparse(args[1]).path
            self.log_colored(f"\033[1;32mGET\033[0m {path} - \033[1;34m{args[2]}\033[0m")
        else:
            self.log_colored(f"\033[1;33m{args[0]}\033[0m {args[1]} - \033[1;34m{args[2]}\033[0m")
    
    def log_colored(self, message):
        """Print colorized log message."""
        print(message)

def run_server():
    """Start the HTTP server and open browser."""
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        url = f"http://localhost:{PORT}/"
        print(f"\033[1;36m=== School Scheduler Development Server ===\033[0m")
        print(f"\033[1;32mServer running at: \033[1;34m{url}\033[0m")
        print(f"\033[1;33mPress Ctrl+C to stop.\033[0m\n")
        
        # Open browser automatically
        webbrowser.open(url)
        
        # Serve until interrupted
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n\033[1;33mServer stopped.\033[0m")

if __name__ == "__main__":
    run_server() 