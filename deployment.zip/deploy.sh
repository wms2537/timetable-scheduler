#!/bin/bash

# Colors for better output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}====================================${NC}"
echo -e "${BLUE}School Scheduler Deployment Script${NC}"
echo -e "${BLUE}====================================${NC}"
echo ""

# Check if BytePlus CLI is installed
echo -e "${GREEN}Checking for BytePlus CLI...${NC}"
if ! command -v byteplus &> /dev/null; then
    echo -e "${RED}BytePlus CLI is not installed. Please install it first.${NC}"
    echo -e "Follow the BytePlus CLI installation instructions from the official documentation."
    exit 1
fi

# Ask for function name
echo -e "${GREEN}Enter a name for your function (e.g., 'school-scheduler'):${NC}"
read FUNCTION_NAME

if [ -z "$FUNCTION_NAME" ]; then
    FUNCTION_NAME="school-scheduler"
    echo -e "${YELLOW}Using default function name: $FUNCTION_NAME${NC}"
fi

# Create requirements.txt
echo -e "${GREEN}Creating requirements.txt...${NC}"
echo "ortools==9.3.10497" > requirements.txt
echo "Successfully created requirements.txt"

# Login to BytePlus
echo -e "${GREEN}Logging in to BytePlus...${NC}"
echo -e "${YELLOW}Note: If you're already logged in, this step will be skipped.${NC}"
byteplus login

# Create a new function
echo -e "${GREEN}Creating function $FUNCTION_NAME...${NC}"
byteplus function create --name $FUNCTION_NAME

# Deploy the function
echo -e "${GREEN}Deploying function...${NC}"
byteplus function deploy --name $FUNCTION_NAME --file scheduler_cloud_function.py --handler handler --runtime python3.9

# Upload requirements
echo -e "${GREEN}Uploading requirements...${NC}"
byteplus function update --name $FUNCTION_NAME --requirements requirements.txt

# Configure environment
echo -e "${GREEN}Configuring environment (timeout and memory)...${NC}"
byteplus function update --name $FUNCTION_NAME --timeout 60 --memory 512

# Get function URL
echo -e "${GREEN}Getting function URL...${NC}"
FUNCTION_URL=$(byteplus function get-url --name $FUNCTION_NAME)

# Update script.js with the function URL
if [ -n "$FUNCTION_URL" ]; then
    echo -e "${GREEN}Updating script.js with function URL...${NC}"
    sed -i'' -e "s|https://your-byteplus-function-url.example.com|$FUNCTION_URL|g" script.js
    echo -e "${GREEN}Successfully updated script.js${NC}"
else
    echo -e "${YELLOW}Couldn't retrieve function URL. Please manually update the URL in script.js${NC}"
fi

echo ""
echo -e "${BLUE}==========================${NC}"
echo -e "${BLUE}Deployment Complete!${NC}"
echo -e "${BLUE}==========================${NC}"
echo ""
echo -e "${GREEN}Your scheduler is now deployed as a BytePlus function.${NC}"
echo -e "${GREEN}Function name: ${YELLOW}$FUNCTION_NAME${NC}"

if [ -n "$FUNCTION_URL" ]; then
    echo -e "${GREEN}Function URL: ${YELLOW}$FUNCTION_URL${NC}"
    echo -e "${GREEN}This URL has been updated in script.js${NC}"
else
    echo -e "${YELLOW}Please get your function URL and update it in script.js:${NC}"
    echo -e "  ${BLUE}byteplus function get-url --name $FUNCTION_NAME${NC}"
fi

echo ""
echo -e "${GREEN}Next steps:${NC}"
echo -e "1. Host the frontend files (index.html and script.js) on a web server"
echo -e "2. Open the web application in your browser and start creating timetables!"
echo "" 